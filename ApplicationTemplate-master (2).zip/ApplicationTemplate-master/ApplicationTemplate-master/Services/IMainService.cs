﻿namespace ApplicationTemplate.Services;

public interface IMainService
{
    void Invoke();
}
